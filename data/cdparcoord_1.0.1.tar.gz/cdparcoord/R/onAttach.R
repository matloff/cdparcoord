
.onAttach <- function(libname, pkgname) {
   packageStartupMessage(
      '\n\n\n\n\n*********************\n\n\n\n\n\n\nType ?quickstart for cdparcoord quick start \n\n\n\n\n`')
}

